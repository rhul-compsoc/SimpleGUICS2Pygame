#!/usr/bin/env python
# -*- coding: latin-1 -*-

"""
Setup of SimpleGUICS2Pygame package (June 13, 2013)

Piece of SimpleGUICS2Pygame.
https://bitbucket.org/OPiMedia/simpleguics2pygame

GPLv3 --- Copyright (C) 2013 Olivier Pirson
http://www.opimedia.be/
"""

from distutils.core import setup

from SimpleGUICS2Pygame.simpleguics2pygame import _VERSION, _WEBSITE


f = open('README.rst')

long_description = ''.join(f.readlines())

f.close()


dir_install = 'Lib/site-packages/SimpleGUICS2Pygame'

setup(name             = 'SimpleGUICS2Pygame',
      version          = _VERSION,
      description      = 'Standard Python module reimplementing the SimpleGUI particular module of CodeSkulptor (a browser Python interpreter).',
      long_description = long_description,
      author           = 'Olivier Pirson',
      author_email     = 'olivier_pirson_opi@yahoo.fr',
      url              = _WEBSITE,
      packages         = ['SimpleGUICS2Pygame'],
      license          = 'GPLv3',
      keywords         = ['CodeSkulptor', 'Pygame', 'SimpleGUI'],
      platforms        = 'any',
      data_files       = [(dir_install, ['README.rst']),
                          (dir_install + '/_img', ['SimpleGUICS2Pygame/_img/simpleguics2pygame-logo-4079748489-6_avatar.png',
                                                   'SimpleGUICS2Pygame/_img/SimpleGUICS2Pygame_cartoon_32x32_t.png',
                                                   'SimpleGUICS2Pygame/_img/SimpleGUICS2Pygame_cartoon_64x64_t.png'])])
